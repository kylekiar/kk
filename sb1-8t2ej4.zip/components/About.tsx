import Image from 'next/image';

const About = () => {
  return (
    <section id="about" className="py-20">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center">
          <div className="md:w-1/2 mb-8 md:mb-0">
            <Image
              src="https://images.unsplash.com/photo-1581092921461-eab62e97a780?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80"
              alt="Kiarie repairing a phone"
              width={600}
              height={400}
              className="rounded-lg shadow-lg"
            />
          </div>
          <div className="md:w-1/2 md:pl-12">
            <h2 className="text-3xl font-bold mb-6">About Repairs by Kiarie</h2>
            <p className="text-lg mb-4">
              With over a decade of experience in phone repairs, Kiarie has built a reputation for excellence and reliability. Our team of skilled technicians is dedicated to providing top-notch repair services for all phone brands and models.
            </p>
            <p className="text-lg mb-4">
              We understand the importance of your device in your daily life, which is why we strive to offer quick turnaround times without compromising on quality. Our state-of-the-art repair facility is equipped with the latest tools and genuine parts to ensure your phone is restored to its optimal condition.
            </p>
            <p className="text-lg">
              Choose Repairs by Kiarie for professional, affordable, and hassle-free phone repair services. Your satisfaction is our top priority!
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;