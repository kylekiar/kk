"use client"

import { useState, useEffect } from 'react';
import Image from 'next/image';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

interface PhoneModel {
  id: number;
  name: string;
  image: string;
  specs: string[];
}

const mockPhoneData: PhoneModel[] = [
  {
    id: 1,
    name: "Samsung Galaxy S24 Ultra",
    image: "https://fdn2.gsmarena.com/vv/bigpic/samsung-galaxy-s24-ultra-5g.jpg",
    specs: ["6.8\" Dynamic AMOLED 2X", "200MP main camera", "5000mAh battery"]
  },
  {
    id: 2,
    name: "Samsung Galaxy A54",
    image: "https://fdn2.gsmarena.com/vv/bigpic/samsung-galaxy-a54.jpg",
    specs: ["6.4\" Super AMOLED", "50MP main camera", "5000mAh battery"]
  },
  {
    id: 3,
    name: "Samsung Galaxy Z Fold5",
    image: "https://fdn2.gsmarena.com/vv/bigpic/samsung-galaxy-z-fold5-5g.jpg",
    specs: ["7.6\" Dynamic AMOLED 2X", "50MP main camera", "4400mAh battery"]
  },
  // Add more mock data as needed
];

const SearchResults = ({ query }: { query: string }) => {
  const [results, setResults] = useState<PhoneModel[]>([]);

  useEffect(() => {
    // Simulate an API call with the search query
    const filteredResults = mockPhoneData.filter(phone => 
      phone.name.toLowerCase().includes(query.toLowerCase())
    );
    setResults(filteredResults);
  }, [query]);

  if (results.length === 0) {
    return <p className="text-white">No results found for "{query}"</p>;
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {results.map(phone => (
        <Card key={phone.id} className="bg-white/90 backdrop-blur-sm">
          <CardHeader>
            <CardTitle>{phone.name}</CardTitle>
          </CardHeader>
          <CardContent>
            <Image 
              src={phone.image} 
              alt={phone.name} 
              width={200} 
              height={200} 
              className="mx-auto mb-4"
            />
            <ul className="list-disc list-inside">
              {phone.specs.map((spec, index) => (
                <li key={index}>{spec}</li>
              ))}
            </ul>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};

export default SearchResults;