"use client"

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import SearchResults from './SearchResults';

const Hero = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [showResults, setShowResults] = useState(false);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setShowResults(true);
  };

  return (
    <section className="bg-cover bg-center py-32" style={{backgroundImage: "url('https://images.unsplash.com/photo-1610945265064-0e34e5519bbf?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80')"}}>
      <div className="container mx-auto px-4 text-center">
        <h1 className="text-4xl md:text-6xl font-bold mb-6 text-white">Expert Phone Repairs</h1>
        <p className="text-xl mb-8 text-white">Fast, reliable, and affordable repairs for all phone brands</p>
        <form onSubmit={handleSearch} className="max-w-md mx-auto flex mb-8">
          <Input
            type="text"
            placeholder="What do you need fixed?"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="flex-grow"
          />
          <Button type="submit" className="ml-2 bg-darkgold hover:bg-darkgold/90 text-white">
            Search
          </Button>
        </form>
        {showResults && <SearchResults query={searchQuery} />}
      </div>
    </section>
  );
};

export default Hero;