import { Smartphone } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-primary text-primary-foreground py-8">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="flex items-center mb-4 md:mb-0">
            <Smartphone className="h-8 w-8 text-darkgold mr-2" />
            <span className="text-xl font-bold">Repairs by Kiarie</span>
          </div>
          <div className="text-sm">
            &copy; {new Date().getFullYear()} Repairs by Kiarie. All rights reserved.
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;