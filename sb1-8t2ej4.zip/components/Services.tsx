import { Smartphone, Cpu, Battery, Wifi } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';

const services = [
  {
    icon: <Smartphone className="h-8 w-8 mb-4 text-darkgold" />,
    title: 'Screen Replacement',
    description: 'High-quality screen replacements for all phone models.',
  },
  {
    icon: <Battery className="h-8 w-8 mb-4 text-darkgold" />,
    title: 'Battery Replacement',
    description: 'Restore your phone\'s battery life with our replacement service.',
  },
  {
    icon: <Cpu className="h-8 w-8 mb-4 text-darkgold" />,
    title: 'Motherboard Repair',
    description: 'Expert motherboard repairs to fix complex issues.',
  },
  {
    icon: <Wifi className="h-8 w-8 mb-4 text-darkgold" />,
    title: 'Connectivity Issues',
    description: 'Resolve Wi-Fi, Bluetooth, and cellular connectivity problems.',
  },
];

const Services = () => {
  return (
    <section id="services" className="py-20 bg-secondary">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-12">Our Services</h2>
        <div className="flex flex-wrap justify-center gap-8">
          {services.map((service, index) => (
            <Card key={index} className="text-center w-64">
              <CardHeader>
                <div className="flex justify-center">{service.icon}</div>
                <CardTitle className="mb-2">{service.title}</CardTitle>
                <CardDescription>{service.description}</CardDescription>
              </CardHeader>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;