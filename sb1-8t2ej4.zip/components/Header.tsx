"use client"

import { useState } from 'react';
import Link from 'next/link';
import { Menu, X, Smartphone } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ModeToggle } from '@/components/mode-toggle';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="bg-background shadow-md">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <Link href="/" className="flex items-center space-x-2">
          <Smartphone className="h-8 w-8 text-darkgold" />
          <span className="text-2xl font-bold text-foreground">Repairs by Kiarie</span>
        </Link>
        <nav className="hidden md:flex space-x-4">
          <Link href="#services" className="text-foreground hover:text-darkgold">Services</Link>
          <Link href="#about" className="text-foreground hover:text-darkgold">About</Link>
          <Link href="#contact" className="text-foreground hover:text-darkgold">Contact</Link>
          <ModeToggle />
        </nav>
        <div className="md:hidden flex items-center">
          <ModeToggle />
          <Button
            variant="ghost"
            size="icon"
            className="ml-2"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </Button>
        </div>
      </div>
      {isMenuOpen && (
        <div className="md:hidden bg-background">
          <nav className="container mx-auto px-4 py-2 flex flex-col space-y-2">
            <Link href="#services" className="text-foreground hover:text-darkgold">Services</Link>
            <Link href="#about" className="text-foreground hover:text-darkgold">About</Link>
            <Link href="#contact" className="text-foreground hover:text-darkgold">Contact</Link>
          </nav>
        </div>
      )}
    </header>
  );
};

export default Header;